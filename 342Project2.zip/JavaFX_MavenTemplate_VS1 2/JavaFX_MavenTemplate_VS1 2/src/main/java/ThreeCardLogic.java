import java.util.ArrayList;
import java.util.Collections;

public class ThreeCardLogic {

    // Evaluates the type of hand and returns an integer value representing the hand strength
    public static int evalHand(ArrayList<Card> hand) {
        if (isStraightFlush(hand)) return 1;
        if (isThreeOfAKind(hand)) return 2;
        if (isStraight(hand)) return 3;
        if (isFlush(hand)) return 4;
        if (isPair(hand)) return 5;
        return 0;  // High card
    }

    // Evaluates the Pair Plus winnings based on the hand and bet amount
    public static int evalPPWinnings(ArrayList<Card> hand, int bet) {
        int handValue = evalHand(hand);
        switch (handValue) {
            case 1: return bet * 40;  // Straight Flush
            case 2: return bet * 30;  // Three of a Kind
            case 3: return bet * 6;   // Straight
            case 4: return bet * 3;   // Flush
            case 5: return bet * 1;   // Pair
            default: return 0;        // High card - no winnings
        }
    }

    // Compares the dealer's hand with the player's hand and returns an integer indicating the winner
    public static int compareHands(ArrayList<Card> dealer, ArrayList<Card> player) {
        int dealerHandValue = evalHand(dealer);
        int playerHandValue = evalHand(player);

        if (dealerHandValue > playerHandValue) return 1;  // Dealer wins
        if (playerHandValue > dealerHandValue) return 2;  // Player wins

        // If hands are of the same type, compare the highest card in each hand
        return compareHighCard(dealer, player);
    }

    // Helper methods to evaluate hand types

    private static boolean isStraightFlush(ArrayList<Card> hand) {
        return isFlush(hand) && isStraight(hand);
    }

    private static boolean isThreeOfAKind(ArrayList<Card> hand) {
        return hand.get(0).getValue() == hand.get(1).getValue() && hand.get(1).getValue() == hand.get(2).getValue();
    }

    private static boolean isStraight(ArrayList<Card> hand) {
        ArrayList<Integer> values = new ArrayList<>();
        for (Card card : hand) values.add(card.getValue());
        Collections.sort(values);

        return (values.get(2) - values.get(1) == 1 && values.get(1) - values.get(0) == 1) ||
               (values.contains(14) && values.contains(2) && values.contains(3));  // Handle A-2-3 straight
    }

    private static boolean isFlush(ArrayList<Card> hand) {
        char suit = hand.get(0).getSuit();
        return hand.get(1).getSuit() == suit && hand.get(2).getSuit() == suit;
    }

    private static boolean isPair(ArrayList<Card> hand) {
        return hand.get(0).getValue() == hand.get(1).getValue() || 
               hand.get(1).getValue() == hand.get(2).getValue() || 
               hand.get(0).getValue() == hand.get(2).getValue();
    }

    // Helper method to compare high cards if hands are of the same type
    private static int compareHighCard(ArrayList<Card> dealer, ArrayList<Card> player) {
        ArrayList<Integer> dealerValues = new ArrayList<>();
        ArrayList<Integer> playerValues = new ArrayList<>();

        for (Card card : dealer) dealerValues.add(card.getValue());
        for (Card card : player) playerValues.add(card.getValue());

        Collections.sort(dealerValues, Collections.reverseOrder());
        Collections.sort(playerValues, Collections.reverseOrder());

        for (int i = 0; i < 3; i++) {
            if (dealerValues.get(i) > playerValues.get(i)) return 1;  // Dealer wins
            if (playerValues.get(i) > dealerValues.get(i)) return 2;  // Player wins
        }
        
        return 0;  // Tie (though this rarely happens in Three Card Poker)
    }
}
