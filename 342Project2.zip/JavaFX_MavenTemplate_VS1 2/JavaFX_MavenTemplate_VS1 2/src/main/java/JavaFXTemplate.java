import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class JavaFXTemplate extends Application {
    Player playerOne;
    Player playerTwo;
    Dealer theDealer;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Welcome to Three Card Poker");

        // Load FXML and controller
        FXMLLoader loader = new FXMLLoader(getClass().getResource("WelcomeScreen.fxml"));
        Parent root = loader.load();

        // Set up controller and pass reference to main app
        WelcomeController controller = loader.getController();
        controller.setMainApp(this);

        Scene welcomeScene = new Scene(root, 700, 700);
        welcomeScene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());

        primaryStage.setScene(welcomeScene);
        primaryStage.show();
    }

    // Method to switch to the game play screen (placeholder for now)
    public void switchToGameScreen(Stage primaryStage) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("GameScreen.fxml"));
            Parent root = loader.load();
            
            GameController controller = loader.getController();
            controller.setMainApp(this);
            
            Scene gameScene = new Scene(root, 700, 700);
            gameScene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());
            
            primaryStage.setScene(gameScene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}