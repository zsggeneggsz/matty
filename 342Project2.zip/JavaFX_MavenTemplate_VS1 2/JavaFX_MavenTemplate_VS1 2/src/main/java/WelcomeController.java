import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class WelcomeController {

    @FXML
    private Button playButton;

    @FXML
    private Button exitButton;

    // Reference to the main application to handle screen switching
    private JavaFXTemplate mainApp;

    public void setMainApp(JavaFXTemplate mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    private void initialize() {
        // Set up button actions
        playButton.setOnAction(e -> handlePlayButton());
        exitButton.setOnAction(e -> System.exit(0));  // Close the application
    }

    @FXML
    private void handlePlayButton() {
        // Get the current stage from the button
        Stage stage = (Stage) playButton.getScene().getWindow();
        mainApp.switchToGameScreen(stage);
    }
}
