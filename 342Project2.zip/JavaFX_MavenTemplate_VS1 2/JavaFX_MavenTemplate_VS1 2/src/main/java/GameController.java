import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.scene.image.ImageView;

public class GameController {
    @FXML private Label gameInfoLabel;
    @FXML private HBox playerOneCards, playerTwoCards, dealerCards;
    @FXML private TextField playerOneAnteBet, playerOnePairPlus;
    @FXML private TextField playerTwoAnteBet, playerTwoPairPlus;
    @FXML private Button playerOnePlayBtn, playerOneFoldBtn;
    @FXML private Button playerTwoPlayBtn, playerTwoFoldBtn;
    @FXML private Label playerOneWinnings, playerTwoWinnings;
    @FXML private Button dealButton, newGameButton;

    private JavaFXTemplate mainApp;
    private boolean playerOneTurn = true;
    private boolean playerTwoTurn = true;

    public void setMainApp(JavaFXTemplate mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    private void initialize() {
        disablePlayButtons(true);
        setupBetValidation();
    }

    private void setupBetValidation() {
        // Add listeners to validate bet amounts
        playerOneAnteBet.textProperty().addListener((obs, old, newValue) -> {
            if (!newValue.matches("\\d*")) {
                playerOneAnteBet.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        // Add similar listeners for other bet fields...
    }

    @FXML
    private void handleDeal() {
        // Validate bets
        if (!validateBets()) {
            gameInfoLabel.setText("Invalid bet amounts. Bets must be between $5 and $25.");
            return;
        }

        // Deal cards
        mainApp.playerOne.setHand(mainApp.theDealer.dealHand());
        mainApp.playerTwo.setHand(mainApp.theDealer.dealHand());

        // Display cards
        displayCards();
        
        // Enable play/fold buttons
        disablePlayButtons(false);
    }

    private boolean validateBets() {
        try {
            int p1Ante = Integer.parseInt(playerOneAnteBet.getText());
            int p2Ante = Integer.parseInt(playerTwoAnteBet.getText());
            
            return p1Ante >= 5 && p1Ante <= 25 && p2Ante >= 5 && p2Ante <= 25;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    @FXML
    private void handlePlayerOnePlay() {
        int anteBet = Integer.parseInt(playerOneAnteBet.getText());
        mainApp.playerOne.setPlayBet(anteBet);
        playerOneTurn = false;
        checkEndRound();
    }

    @FXML
    private void handlePlayerTwoPlay() {
        int anteBet = Integer.parseInt(playerTwoAnteBet.getText());
        mainApp.playerTwo.setPlayBet(anteBet);
        playerTwoTurn = false;
        checkEndRound();
    }

    @FXML
    private void handlePlayerOneFold() {
        mainApp.playerOne.setPlayBet(0);  // Set play bet to 0 when folding
        playerOneTurn = false;
        checkEndRound();
    }

    @FXML
    private void handlePlayerTwoFold() {
        mainApp.playerTwo.setPlayBet(0);  // Set play bet to 0 when folding
        playerTwoTurn = false;
        checkEndRound();
    }

    private void checkEndRound() {
        if (!playerOneTurn && !playerTwoTurn) {
            evaluateHands();
        }
    }

    private void evaluateHands() {
        // Show dealer's cards
        displayDealerCards();

        // Add pause for dramatic effect
        PauseTransition pause = new PauseTransition(Duration.seconds(1.5));
        pause.setOnFinished(event -> {
            // Evaluate hands and update winnings
            evaluatePlayerHand(mainApp.playerOne, 1);
            evaluatePlayerHand(mainApp.playerTwo, 2);
            
            // Update winnings display
            updateWinningsDisplay();
            
            // Enable new game
            dealButton.setDisable(false);
            resetBetFields();
        });
        pause.play();
    }

    @FXML
    private void handleNewGame() {
        // Reset game state
        playerOneTurn = true;
        playerTwoTurn = true;
        resetBetFields();
        clearCards();
        gameInfoLabel.setText("Place your bets!");
    }

    @FXML
    private void handleExit() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ExitConfirmation.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleFreshStart() {
        mainApp.playerOne = new Player();
        mainApp.playerTwo = new Player();
        mainApp.theDealer = new Dealer();
        handleNewGame();
        updateWinningsDisplay();
    }

    @FXML
    private void handleNewLook() {
        Scene scene = dealButton.getScene();
        if (scene.getStylesheets().contains("styles.css")) {
            scene.getStylesheets().clear();
            scene.getStylesheets().add("alternateStyles.css");
        } else {
            scene.getStylesheets().clear();
            scene.getStylesheets().add("styles.css");
        }
    }

    private void disablePlayButtons(boolean disable) {
        playerOnePlayBtn.setDisable(disable);
        playerOneFoldBtn.setDisable(disable);
        playerTwoPlayBtn.setDisable(disable);
        playerTwoFoldBtn.setDisable(disable);
    }

    private void displayCards() {
        // Clear existing cards
        playerOneCards.getChildren().clear();
        playerTwoCards.getChildren().clear();
        
        // Display player cards
        for (Card card : mainApp.playerOne.getHand()) {
            playerOneCards.getChildren().add(new CardView(card));
        }
        
        for (Card card : mainApp.playerTwo.getHand()) {
            playerTwoCards.getChildren().add(new CardView(card));
        }
    }

    private void displayDealerCards() {
        dealerCards.getChildren().clear();
        for (Card card : mainApp.theDealer.getHand()) {
            dealerCards.getChildren().add(new CardView(card));
        }
    }

    private void evaluatePlayerHand(Player player, int playerNum) {
        ThreeCardLogic.compareHands(mainApp.theDealer.getHand(), player.getHand());
        int anteBet = playerNum == 1 ? 
            Integer.parseInt(playerOneAnteBet.getText()) : 
            Integer.parseInt(playerTwoAnteBet.getText());
        int pairPlus = playerNum == 1 ? 
            Integer.parseInt(playerOnePairPlus.getText()) : 
            Integer.parseInt(playerTwoPairPlus.getText());
        
        player.updateWinnings(anteBet, pairPlus);
    }

    private void updateWinningsDisplay() {
        playerOneWinnings.setText("$" + mainApp.playerOne.getWinnings());
        playerTwoWinnings.setText("$" + mainApp.playerTwo.getWinnings());
    }

    private void resetBetFields() {
        playerOneAnteBet.setText("");
        playerOnePairPlus.setText("");
        playerTwoAnteBet.setText("");
        playerTwoPairPlus.setText("");
    }

    private void clearCards() {
        playerOneCards.getChildren().clear();
        playerTwoCards.getChildren().clear();
        dealerCards.getChildren().clear();
    }

}