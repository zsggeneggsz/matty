import java.util.ArrayList;

public class Player {
    // Data members
    private ArrayList<Card> hand;
    private int anteBet;
    private int playBet;
    private int pairPlusBet;
    private int totalWinnings;
    private int winnings = 0;

    // No-argument constructor
    public Player() {
        hand = new ArrayList<>();  // Initialize the player's hand as an empty list
        anteBet = 0;               // Initial ante bet is 0
        playBet = 0;               // Initial play bet is 0
        pairPlusBet = 0;           // Initial pair plus bet is 0
        totalWinnings = 0;         // Initial total winnings is 0
    }

    // Getters and setters for anteBet, playBet, pairPlusBet, and totalWinnings
    public ArrayList<Card> getHand() {
        return new ArrayList<>(hand);
    }

    public void setHand(ArrayList<Card> newHand) {
        hand = new ArrayList<>(newHand);  // Store a copy of the given hand
    }

    public int getAnteBet() {
        return anteBet;
    }

    public void setAnteBet(int anteBet) {
        this.anteBet = anteBet;
    }

    public int getPlayBet() {
        return playBet;
    }

    public void setPlayBet(int playBet) {
        this.playBet = playBet;
    }

    public int getPairPlusBet() {
        return pairPlusBet;
    }

    public void setPairPlusBet(int pairPlusBet) {
        this.pairPlusBet = pairPlusBet;
    }

    public int getTotalWinnings() {
        return totalWinnings;
    }

    public void updateTotalWinnings(int amount) {
        totalWinnings += amount;  // Update winnings by adding or subtracting amount
    }

    public int getWinnings() {
        return winnings;
    }

    // Method to reset the hand and bets for a new game
    public void resetForNewGame() {
        hand.clear();   // Clear the player's hand
        anteBet = 0;    // Reset ante bet
        playBet = 0;    // Reset play bet
        pairPlusBet = 0; // Reset pair plus bet
    }

    public void updateWinnings(int anteBet, int pairPlus) {
        // Add ante and pair plus bets to total winnings
        totalWinnings += anteBet + pairPlus;
    }
}
