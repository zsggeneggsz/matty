import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Deck extends ArrayList<Card> {
    // Constructor to create and shuffle a new deck of 52 cards
    public Deck() {
        newDeck();
    }

    // Method to clear the current deck and create a new shuffled deck of 52 cards
    public void newDeck() {
        // Clear any existing cards in the deck
        this.clear();

        // Define suits and values for a standard deck
        char[] suits = {'C', 'D', 'S', 'H'};
        int[] values = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};

        // Add each card to the deck
        for (char suit : suits) {
            for (int value : values) {
                this.add(new Card(suit, value));
            }
        }

        // Shuffle the deck randomly
        Collections.shuffle(this, new Random());
    }
}
