public class Card {
	private char suit; 
	private int value;
	
	
	public Card(char suit, int value) {
        if (suit != 'C' && suit != 'D' && suit != 'S' && suit != 'H') {
            throw new IllegalArgumentException("Invalid suit. Use 'C', 'D', 'S', or 'H'.");
        }
        if (value < 2 || value > 14) {
            throw new IllegalArgumentException("Invalid value. Must be between 2 and 14.");
        }
        this.suit = suit;
        this.value = value;
    }
	
	public char getSuit() {
		return suit;
	}
	public int getValue() {
		return value;
	}
	
	@Override
	public String toString() {
        String displayValue;
        switch (value) {
            case 11: displayValue = "J"; break;
            case 12: displayValue = "Q"; break;
            case 13: displayValue = "K"; break;
            case 14: displayValue = "A"; break;
            default: displayValue = String.valueOf(value);
        }
        return displayValue + suit;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Card other = (Card) obj;
        return suit == other.suit && value == other.value;
    }

    @Override
    public int hashCode() {
        return 31 * Character.hashCode(suit) + Integer.hashCode(value);
    }
}
