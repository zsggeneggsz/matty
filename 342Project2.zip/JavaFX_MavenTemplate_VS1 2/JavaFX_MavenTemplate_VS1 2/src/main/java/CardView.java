import javafx.scene.image.ImageView;
import javafx.scene.image.Image;

public class CardView extends ImageView {
    public CardView(Card card) {
        String imagePath = "/images/" + card.toString() + ".png";
        Image cardImage = new Image(getClass().getResourceAsStream(imagePath));
        setImage(cardImage);
        setFitWidth(100);  // Adjust size as needed
        setFitHeight(145);
    }
} 