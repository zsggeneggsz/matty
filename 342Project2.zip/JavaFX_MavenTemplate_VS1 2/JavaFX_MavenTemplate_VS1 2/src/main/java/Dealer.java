import java.util.ArrayList;

public class Dealer {
    // Data members
    private Deck theDeck;
    private ArrayList<Card> dealersHand;
    private static final int RESHUFFLE_THRESHOLD = 34; // Reshuffle when 34 or fewer cards remain
    private boolean dealerHasInitialHand = false;  // Add this flag

    // No-arg constructor
    public Dealer() {
        theDeck = new Deck(); // Initialize a new shuffled deck
        dealersHand = new ArrayList<>(); // Initialize the dealer's hand as an empty list
        theDeck.newDeck();
    }

    // Method to deal a hand of three cards
    public ArrayList<Card> dealHand() {
        // Check if deck will have 34 or fewer cards after dealing this hand
        if (theDeck.size() - 3 <= RESHUFFLE_THRESHOLD) {  // Back to -3 for normal checks
            theDeck.newDeck(); // Create new shuffled deck of 52 cards
            dealerHasInitialHand = false;  // Reset flag when reshuffling
            dealersHand.clear();
        }

        // Deal to dealer only on first hand
        if (!dealerHasInitialHand) {
            for (int i = 0; i < 3; i++) {
                dealersHand.add(theDeck.remove(0));
            }
            dealerHasInitialHand = true;
        }

        // Deal player's hand
        ArrayList<Card> playerHand = new ArrayList<Card>();
        for (int i = 0; i < 3; i++) {
            playerHand.add(theDeck.remove(0));
        }
        return playerHand;
    }
    
    public int getDeckSize() {
        return theDeck.size();
    }

    // Getter for the dealer's hand
    public ArrayList<Card> getDealersHand() {
        return dealersHand;
    }

    public ArrayList<Card> getHand() {
        return dealersHand;
    }
}