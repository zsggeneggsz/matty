import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.HashSet;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;


public class MyTest {
	
	// Card Class Testcases

	// Constructor Tests
    @Test
    public void testValidCardCreation() {
        Card card = new Card('H', 10);
        assertEquals('H', card.getSuit(), "Suit should be 'H'");
        assertEquals(10, card.getValue(), "Value should be 10");
    }

    @Test
    public void testInvalidSuit() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> new Card('X', 5));
        assertEquals("Invalid suit. Use 'C', 'D', 'S', or 'H'.", exception.getMessage(), "Invalid suit should throw an exception");
    }

    @Test
    public void testInvalidValueTooLow() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> new Card('S', 1));
        assertEquals("Invalid value. Must be between 2 and 14.", exception.getMessage(), "Value below 2 should throw an exception");
    }

    @Test
    public void testInvalidValueTooHigh() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> new Card('D', 15));
        assertEquals("Invalid value. Must be between 2 and 14.", exception.getMessage(), "Value above 14 should throw an exception");
    }

    @Test
    public void testBoundaryValueLow() {
        Card card = new Card('C', 2);
        assertEquals(2, card.getValue(), "Boundary value of 2 should be allowed");
    }

    @Test
    public void testBoundaryValueHigh() {
        Card card = new Card('C', 14);
        assertEquals(14, card.getValue(), "Boundary value of 14 should be allowed");
    }

    // Getter Tests
    @Test
    public void testGetSuit() {
        Card card = new Card('S', 7);
        assertEquals('S', card.getSuit(), "getSuit() should return 'S'");
    }

    @Test
    public void testGetValue() {
        Card card = new Card('D', 13);
        assertEquals(13, card.getValue(), "getValue() should return 13");
    }

    // toString Tests for Numeric Values
    @Test
    public void testToStringNumericCard() {
        Card card = new Card('H', 9);
        assertEquals("9H", card.toString(), "toString() should return '9H' for value 9 and suit 'H'");
    }

    @Test
    public void testToStringFaceCardJack() {
        Card card = new Card('D', 11);
        assertEquals("JD", card.toString(), "toString() should return 'JD' for value 11 (Jack) and suit 'D'");
    }

    @Test
    public void testToStringFaceCardQueen() {
        Card card = new Card('C', 12);
        assertEquals("QC", card.toString(), "toString() should return 'QC' for value 12 (Queen) and suit 'C'");
    }

    @Test
    public void testToStringFaceCardAce() {
        Card card = new Card('S', 14);
        assertEquals("AS", card.toString(), "toString() should return 'AS' for value 14 (Ace) and suit 'S'");
    }
	
	//Deck Class Testcases
	
    // Constructor Tests
    @Test
    public void testDeckConstructorCreates52Cards() {
        Deck deck = new Deck();
        assertEquals(52, deck.size(), "Deck should contain 52 cards after construction.");
    }

    @Test
    public void testDeckConstructorUniqueCards() {
        Deck deck = new Deck();
        HashSet<String> uniqueCards = new HashSet<>();
        for (Card card : deck) {
            uniqueCards.add(card.toString());
        }
        assertEquals(52, uniqueCards.size(), "Deck should contain 52 unique cards.");
    }

    @Test
    public void testDeckContainsAllSuits() {
        Deck deck = new Deck();
        boolean hasClubs = deck.stream().anyMatch(card -> card.getSuit() == 'C');
        boolean hasDiamonds = deck.stream().anyMatch(card -> card.getSuit() == 'D');
        boolean hasSpades = deck.stream().anyMatch(card -> card.getSuit() == 'S');
        boolean hasHearts = deck.stream().anyMatch(card -> card.getSuit() == 'H');

        assertTrue(hasClubs && hasDiamonds && hasSpades && hasHearts, "Deck should contain all four suits.");
    }

    @Test
    public void testDeckContainsAllValues() {
        Deck deck = new Deck();
        HashSet<Integer> valuesInDeck = new HashSet<>();
        for (Card card : deck) {
            valuesInDeck.add(card.getValue());
        }

        for (int value = 2; value <= 14; value++) {
            assertTrue(valuesInDeck.contains(value), "Deck should contain all values from 2 to 14.");
        }
    }

    // newDeck() Method Tests
    @Test
    public void testNewDeckResetsDeckTo52Cards() {
        Deck deck = new Deck();
        deck.remove(0);  // Remove a card to test reset
        assertEquals(51, deck.size(), "Deck should contain 51 cards after removing one.");
        
        deck.newDeck();
        assertEquals(52, deck.size(), "Deck should contain 52 cards after calling newDeck().");
    }

    @Test
    public void testNewDeckCreatesUniqueCards() {
        Deck deck = new Deck();
        deck.newDeck();
        
        HashSet<String> uniqueCards = new HashSet<>();
        for (Card card : deck) {
            uniqueCards.add(card.toString());
        }
        assertEquals(52, uniqueCards.size(), "newDeck() should create a deck with 52 unique cards.");
    }

    @Test
    public void testNewDeckShufflesCards() {
        Deck firstDeck = new Deck();
        Deck secondDeck = new Deck();
        secondDeck.newDeck();
        
        boolean differentOrder = false;
        for (int i = 0; i < 52; i++) {
            if (!firstDeck.get(i).toString().equals(secondDeck.get(i).toString())) {
                differentOrder = true;
                break;
            }
        }
        
        assertTrue(differentOrder, "newDeck() should shuffle cards, so order should differ between two decks.");
    }

    @Test
    public void testNewDeckContainsAllSuits() {
        Deck deck = new Deck();
        deck.newDeck();

        boolean hasClubs = deck.stream().anyMatch(card -> card.getSuit() == 'C');
        boolean hasDiamonds = deck.stream().anyMatch(card -> card.getSuit() == 'D');
        boolean hasSpades = deck.stream().anyMatch(card -> card.getSuit() == 'S');
        boolean hasHearts = deck.stream().anyMatch(card -> card.getSuit() == 'H');

        assertTrue(hasClubs && hasDiamonds && hasSpades && hasHearts, "newDeck() should contain all four suits.");
    }

    @Test
    public void testNewDeckContainsAllValues() {
        Deck deck = new Deck();
        deck.newDeck();
        
        HashSet<Integer> valuesInDeck = new HashSet<>();
        for (Card card : deck) {
            valuesInDeck.add(card.getValue());
        }

        for (int value = 2; value <= 14; value++) {
            assertTrue(valuesInDeck.contains(value), "newDeck() should contain all values from 2 to 14.");
        }
    }

    // Tests to check randomness after multiple shuffles
    @Test
    public void testMultipleDeckShufflesProduceDifferentOrders() {
        Deck deck = new Deck();
        Deck anotherDeck = new Deck();

        int matchCount = 0;
        for (int i = 0; i < 52; i++) {
            if (deck.get(i).toString().equals(anotherDeck.get(i).toString())) {
                matchCount++;
            }
        }
        
        assertTrue(matchCount < 52, "Multiple shuffles should not produce the same card order.");
    }

    // Edge Case Test
    @Test
    public void testEmptyDeckRecreation() {
        Deck deck = new Deck();
        deck.clear();
        assertEquals(0, deck.size(), "Deck should be empty after clearing.");

        deck.newDeck();
        assertEquals(52, deck.size(), "Deck should have 52 cards after calling newDeck() on an empty deck.");
    }

    @Test
    public void testDeckConsistencyAfterRecreation() {
        Deck deck = new Deck();
        deck.newDeck();
        
        HashSet<String> firstDeckSnapshot = new HashSet<>();
        for (Card card : deck) {
            firstDeckSnapshot.add(card.toString());
        }

        deck.newDeck();  // Regenerate the deck
        
        HashSet<String> secondDeckSnapshot = new HashSet<>();
        for (Card card : deck) {
            secondDeckSnapshot.add(card.toString());
        }
        
        assertEquals(firstDeckSnapshot, secondDeckSnapshot, "newDeck() should consistently recreate a valid 52-card set.");
    }
	
	// Dealer Test Cases
    
    // Constructor Tests
    @Test
    public void testDealerConstructorInitializesDeck() {
        Dealer dealer = new Dealer();
        assertNotNull(dealer, "Dealer should be initialized.");
        assertNotNull(dealer.getDealersHand(), "Dealer's hand should be initialized as an empty ArrayList.");
    }

    @Test
    public void testDealerDeckSizeAfterInitialization() {
    Dealer dealer = new Dealer();
    assertEquals(52, dealer.getDeckSize(), "Deck should contain 52 cards at initialization.");
    }

    // dealHand() Method Tests
    @Test
    public void testDealHandReturnsThreeCards() {
        Dealer dealer = new Dealer();
        ArrayList<Card> hand = dealer.dealHand();
        assertEquals(3, hand.size(), "dealHand() should return exactly 3 cards.");
    }

    @Test
    public void testDealHandReducesDeckSize() {
        Dealer dealer = new Dealer();
        int initialDeckSize = 52;
        dealer.dealHand();
        assertEquals(initialDeckSize - 3, dealer.getDeckSize(), "Deck size should reduce by 3 after dealing a hand.");
    }

    @Test
    public void testDealHandUniqueCards() {
        Dealer dealer = new Dealer();
        ArrayList<Card> firstHand = dealer.dealHand();
        ArrayList<Card> secondHand = dealer.dealHand();

        assertFalse(firstHand.equals(secondHand), "Consecutive hands should not be the same.");
    }

    @Test
    public void testDeckReshufflesWhenLow() {
        Dealer dealer = new Dealer();
        for (int i = 0; i < 6; i++) {
            dealer.dealHand();
        }
        assertEquals(49, dealer.getDeckSize(), "Deck should reshuffle when 34 or fewer cards are left.");
    }

    @Test
    public void testReshuffledDeckStillDealsCorrectNumberOfCards() {
        Dealer dealer = new Dealer();
        for (int i = 0; i < 7; i++) {
            dealer.dealHand();
        }
        ArrayList<Card> hand = dealer.dealHand();
        assertEquals(3, hand.size(), "After reshuffling, dealHand() should still return 3 cards.");
    }

    // getDealersHand() Method Tests
    @Test
    public void testGetDealersHandReturnsThreeCards() {
        Dealer dealer = new Dealer();
        dealer.dealHand();
        assertEquals(3, dealer.getDealersHand().size(), "getDealersHand() should return exactly 3 cards after dealing a hand.");
    }

    @Test
    public void testGetDealersHandReturnsCopy() {
        Dealer dealer = new Dealer();
        ArrayList<Card> hand = dealer.dealHand();
        ArrayList<Card> handCopy = dealer.getDealersHand();

        handCopy.clear(); // Clear the copy to test immutability
        assertEquals(3, dealer.getDealersHand().size(), "getDealersHand() should return a copy, not a reference to the dealer's hand.");
    }

    @Test
    public void testDealersHandConsistency() {
        Dealer dealer = new Dealer();
        ArrayList<Card> hand = dealer.dealHand();
        assertEquals(hand, dealer.getDealersHand(), "Dealer's hand should remain consistent after dealing.");
    }

    // Edge Cases
    @Test
    public void testDealHandWithExactReshuffleThreshold() {
        Dealer dealer = new Dealer();
        for (int i = 0; i < 6; i++) {
            dealer.dealHand();
        }
        ArrayList<Card> lastHand = dealer.dealHand();
        assertEquals(3, lastHand.size(), "Dealer should deal 3 cards when exactly 34 cards remain.");
    }

    @Test
    public void testMultipleDealsWithoutReshuffle() {
        Dealer dealer = new Dealer();
        for (int i = 0; i < 5; i++) {
            ArrayList<Card> hand = dealer.dealHand();
            assertEquals(3, hand.size(), "Each deal should return exactly 3 cards before reshuffling is required.");
        }
    }

    @Test
    public void testDeckNotNullAfterMultipleDeals() {
        Dealer dealer = new Dealer();
        for (int i = 0; i < 10; i++) {
            dealer.dealHand();
        }
        assertNotNull(dealer.getDeckSize(), "Deck should not be null after multiple deals.");
    }

    @Test
    public void testDealersHandConsistencyAfterReshuffle() {
        Dealer dealer = new Dealer();
        for (int i = 0; i < 8; i++) {
            dealer.dealHand();
        }
        ArrayList<Card> handAfterReshuffle = dealer.getDealersHand();
        assertEquals(3, handAfterReshuffle.size(), "Dealer's hand should maintain a consistent size even after reshuffling.");
    }
	
}